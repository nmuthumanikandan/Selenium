package pages;

import base.ProjectSpecificMethods;

public class ViewLeadPage extends ProjectSpecificMethods{

}
