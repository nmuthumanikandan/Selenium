package testcase;

import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class CreateLead extends ProjectSpecificMethods {
	
	@Test
	public void runCreateLead() throws InterruptedException {
		new LoginPage(driver)
		.enterUsername("DemoCSR")
		.enterPassword("crmsfa")
		.clickLoginButton()
		.clickCrmsfaLink()
		.clickLeadsLink();

	}

}
